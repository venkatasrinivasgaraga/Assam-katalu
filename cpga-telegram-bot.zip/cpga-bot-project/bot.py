import os
import logging
import time
import threading
import asyncio
from telegram._bot import Bot

# Configure logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Admin Telegram user IDs (can be configured later)
ADMIN_USER_IDS = []
if os.environ.get('ADMIN_TELEGRAM_IDS'):
    try:
        ADMIN_USER_IDS = [int(id.strip()) for id in os.environ.get('ADMIN_TELEGRAM_IDS').split(',')]
    except ValueError:
        logger.error("Invalid ADMIN_TELEGRAM_IDS format. Should be comma-separated integers.")

# Telegram bot token from environment variable
TELEGRAM_TOKEN = os.environ.get('TELEGRAM_BOT_TOKEN', '')

# Global variable to store the last update ID processed
last_update_id = 0

# Function to handle the /start command
async def handle_start_command(bot, message, user_info):
    """Handle the /start command"""
    first_name = user_info.get('first_name', 'Friend')
    text = f"Hi {first_name}! I'm the CPGA Bot. Use /getcpga to get information about CPGA. \n\nAdmin users can use /setcpga to update the message."
    await bot.send_message(chat_id=message['chat']['id'], text=text)

# Function to handle the /help command
async def handle_help_command(bot, message, user_info, user_id):
    """Handle the /help command"""
    help_text = (
        "Available commands:\n"
        "/start - Start the bot\n"
        "/help - Show this help message\n"
        "/getcpga - Get CPGA information\n"
    )
    
    if user_id in ADMIN_USER_IDS:
        help_text += "\nAdmin commands:\n/setcpga <message> - Set the CPGA message"
    
    await bot.send_message(chat_id=message['chat']['id'], text=help_text)

# Function to handle the /getcpga command
async def handle_getcpga_command(bot, message, bot_config):
    """Handle the /getcpga command"""
    await bot.send_message(chat_id=message['chat']['id'], text=bot_config["getcpga_message"])

# Function to handle the /setcpga command
async def handle_setcpga_command(bot, message, bot_config, user_id, command_text):
    """Handle the /setcpga command (admin only)"""
    if user_id not in ADMIN_USER_IDS:
        await bot.send_message(chat_id=message['chat']['id'], text="Sorry, only admins can use this command.")
        return
    
    # Extract the new message from the command
    parts = command_text.split(' ', 1)
    if len(parts) < 2:
        await bot.send_message(
            chat_id=message['chat']['id'], 
            text="Please provide a message after the command, e.g., /setcpga Your message here"
        )
        return
    
    new_message = parts[1].strip()
    bot_config["getcpga_message"] = new_message
    
    await bot.send_message(
        chat_id=message['chat']['id'], 
        text=f"CPGA message updated successfully. New message:\n\n{new_message}"
    )

# Function to handle unknown commands
async def handle_unknown_command(bot, message):
    """Handle unknown commands"""
    await bot.send_message(
        chat_id=message['chat']['id'], 
        text="Sorry, I don't understand that command. Use /help to see available commands."
    )

# Main bot polling function
async def poll_updates(bot, bot_config):
    """Poll for updates from Telegram"""
    global last_update_id
    
    try:
        updates = await bot.get_updates(offset=last_update_id+1, timeout=30)
        
        for update in updates:
            # Process new update and update the last_update_id
            if update.update_id:
                last_update_id = update.update_id
            
            # Check if the update contains a message
            if not update.message:
                continue
            
            message = update.message.to_dict()
            
            # Check if the message contains text
            if 'text' not in message:
                continue
            
            text = message['text']
            chat_id = message['chat']['id']
            user_id = message['from']['id']
            user_info = message['from']
            
            # Process commands
            if text.startswith('/start'):
                await handle_start_command(bot, message, user_info)
            elif text.startswith('/help'):
                await handle_help_command(bot, message, user_info, user_id)
            elif text.startswith('/getcpga'):
                await handle_getcpga_command(bot, message, bot_config)
            elif text.startswith('/setcpga'):
                await handle_setcpga_command(bot, message, bot_config, user_id, text)
            elif text.startswith('/'):
                await handle_unknown_command(bot, message)
    
    except Exception as e:
        logger.error(f"Error in poll_updates: {e}")

# Function to run async loop in the thread
def run_async_bot(bot_config):
    asyncio.run(async_bot_main(bot_config))

# Main async function
async def async_bot_main(bot_config):
    if not TELEGRAM_TOKEN:
        logger.error("TELEGRAM_BOT_TOKEN environment variable not set!")
        # Continue with a dummy process that just sleeps, so the web app can still run
        while True:
            await asyncio.sleep(60)
    
    try:
        bot = Bot(token=TELEGRAM_TOKEN)
        logger.info("Starting Telegram bot...")
        
        # Run the bot polling in a loop
        while True:
            try:
                await poll_updates(bot, bot_config)
            except Exception as e:
                logger.error(f"Error in bot polling: {e}")
                # Sleep before retrying
                await asyncio.sleep(5)
    
    except Exception as e:
        logger.error(f"Failed to start the bot: {e}")
        # Continue with a dummy process that just sleeps, so the web app can still run
        while True:
            await asyncio.sleep(60)

# Function that will be executed in a separate thread
def start_bot(bot_config):
    # Run the async code in the thread
    run_async_bot(bot_config)
